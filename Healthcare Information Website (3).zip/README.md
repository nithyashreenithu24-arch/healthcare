
  # Healthcare Information Website

  This is a code bundle for Healthcare Information Website. The original project is available at https://www.figma.com/design/dP00NrZlLlFPiRSbS2MiU4/Healthcare-Information-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  