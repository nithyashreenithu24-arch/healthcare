import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { HealthTips } from "./components/HealthTips";
import { Doctors } from "./components/Doctors";
import { AppointmentBooking } from "./components/AppointmentBooking";
import { Services } from "./components/Services";
import { About } from "./components/About";
import { Testimonials } from "./components/Testimonials";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <HealthTips />
        <Doctors />
        <AppointmentBooking />
        <Services />
        <Testimonials />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}