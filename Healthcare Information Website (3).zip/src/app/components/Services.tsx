import { Heart, Stethoscope, Brain, Baby, Eye, Bone, Activity, Pill } from 'lucide-react';

const services = [
  {
    id: 1,
    name: 'Cardiology',
    icon: Heart,
    description: 'Comprehensive heart care including diagnostics, treatment, and preventive cardiology services.',
    color: 'bg-red-100 text-red-600'
  },
  {
    id: 2,
    name: 'General Medicine',
    icon: Stethoscope,
    description: 'Primary care services for routine checkups, illness diagnosis, and health management.',
    color: 'bg-blue-100 text-blue-600'
  },
  {
    id: 3,
    name: 'Neurology',
    icon: Brain,
    description: 'Expert diagnosis and treatment of nervous system disorders and neurological conditions.',
    color: 'bg-purple-100 text-purple-600'
  },
  {
    id: 4,
    name: 'Pediatrics',
    icon: Baby,
    description: 'Specialized medical care for infants, children, and adolescents with compassionate approach.',
    color: 'bg-pink-100 text-pink-600'
  },
  {
    id: 5,
    name: 'Ophthalmology',
    icon: Eye,
    description: 'Complete eye care services including vision testing, treatment, and surgical procedures.',
    color: 'bg-teal-100 text-teal-600'
  },
  {
    id: 6,
    name: 'Orthopedics',
    icon: Bone,
    description: 'Treatment of bone, joint, and muscle conditions with advanced surgical techniques.',
    color: 'bg-orange-100 text-orange-600'
  },
  {
    id: 7,
    name: 'Emergency Care',
    icon: Activity,
    description: '24/7 emergency services with rapid response team and advanced life support.',
    color: 'bg-red-100 text-red-600'
  },
  {
    id: 8,
    name: 'Pharmacy',
    icon: Pill,
    description: 'In-house pharmacy with wide range of medications and expert pharmaceutical guidance.',
    color: 'bg-green-100 text-green-600'
  }
];

export function Services() {
  return (
    <section id="services" className="py-16 bg-gradient-to-br from-green-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
            Our Medical Services
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We offer a wide range of medical services and departments to meet all your healthcare needs
            with state-of-the-art facilities and experienced medical professionals.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => {
            const IconComponent = service.icon;
            return (
              <div
                key={service.id}
                className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-shadow border-t-4 border-blue-600"
              >
                <div className={`w-14 h-14 rounded-lg ${service.color} flex items-center justify-center mb-4`}>
                  <IconComponent className="w-7 h-7" />
                </div>
                <h3 className="font-bold text-blue-900 mb-2">{service.name}</h3>
                <p className="text-sm text-gray-600">{service.description}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-12 bg-blue-600 rounded-lg p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-3">24/7 Emergency Services Available</h3>
          <p className="mb-4">Our emergency department is always open to serve you in critical situations.</p>
          <p className="text-xl font-bold">Emergency Hotline: +1 (555) 911-HELP</p>
        </div>
      </div>
    </section>
  );
}
