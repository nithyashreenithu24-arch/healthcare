import { useState } from 'react';
import { GraduationCap, Clock, Phone, Mail, Calendar, DollarSign, Search } from 'lucide-react';

const doctors = [
  {
    id: 1,
    name: 'Dr. Sarah Johnson',
    specialization: 'Cardiologist',
    experience: '15 years',
    qualification: 'MD, FACC',
    availability: 'Mon, Wed, Fri (9 AM - 5 PM)',
    phone: '+1 (555) 123-4567',
    email: 'sarah.johnson@healthcareplus.com',
    fee: '$150',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop'
  },
  {
    id: 2,
    name: 'Dr. Michael Chen',
    specialization: 'Pediatrician',
    experience: '12 years',
    qualification: 'MD, FAAP',
    availability: 'Tue, Thu, Sat (10 AM - 6 PM)',
    phone: '+1 (555) 234-5678',
    email: 'michael.chen@healthcareplus.com',
    fee: '$120',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&h=400&fit=crop'
  },
  {
    id: 3,
    name: 'Dr. Emily Rodriguez',
    specialization: 'Dermatologist',
    experience: '10 years',
    qualification: 'MD, FAAD',
    availability: 'Mon, Tue, Thu (11 AM - 7 PM)',
    phone: '+1 (555) 345-6789',
    email: 'emily.rodriguez@healthcareplus.com',
    fee: '$130',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400&h=400&fit=crop'
  },
  {
    id: 4,
    name: 'Dr. James Wilson',
    specialization: 'Orthopedic Surgeon',
    experience: '18 years',
    qualification: 'MD, FAAOS',
    availability: 'Wed, Fri, Sat (8 AM - 4 PM)',
    phone: '+1 (555) 456-7890',
    email: 'james.wilson@healthcareplus.com',
    fee: '$200',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop'
  },
  {
    id: 5,
    name: 'Dr. Priya Patel',
    specialization: 'General Physician',
    experience: '8 years',
    qualification: 'MD, ABFM',
    availability: 'Mon - Sat (9 AM - 5 PM)',
    phone: '+1 (555) 567-8901',
    email: 'priya.patel@healthcareplus.com',
    fee: '$100',
    image: 'https://images.unsplash.com/photo-1638202993928-7267aad84c31?w=400&h=400&fit=crop'
  },
  {
    id: 6,
    name: 'Dr. Robert Martinez',
    specialization: 'Neurologist',
    experience: '14 years',
    qualification: 'MD, FAAN',
    availability: 'Tue, Thu, Fri (10 AM - 6 PM)',
    phone: '+1 (555) 678-9012',
    email: 'robert.martinez@healthcareplus.com',
    fee: '$180',
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&h=400&fit=crop'
  }
];

export function Doctors() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState('All');

  const specializations = ['All', ...Array.from(new Set(doctors.map(d => d.specialization)))];

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doctor.specialization.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialization = selectedSpecialization === 'All' || doctor.specialization === selectedSpecialization;
    return matchesSearch && matchesSpecialization;
  });

  return (
    <section id="doctors" className="py-16 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
            Our Expert Medical Team
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Meet our team of highly qualified doctors dedicated to providing you with the best healthcare services.
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by name or specialization..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={selectedSpecialization}
            onChange={(e) => setSelectedSpecialization(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {specializations.map(spec => (
              <option key={spec} value={spec}>{spec}</option>
            ))}
          </select>
        </div>

        {/* Doctors Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors.map((doctor) => (
            <div key={doctor.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
              <img
                src={doctor.image}
                alt={doctor.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="font-bold text-blue-900 mb-1">{doctor.name}</h3>
                <p className="text-blue-600 mb-4">{doctor.specialization}</p>

                <div className="space-y-2 text-sm text-gray-700">
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-green-600" />
                    <span>{doctor.qualification}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span>{doctor.experience} experience</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-purple-600" />
                    <span className="text-xs">{doctor.availability}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-green-600" />
                    <span>Consultation: {doctor.fee}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-teal-600" />
                    <span className="text-xs">{doctor.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-orange-600" />
                    <span className="text-xs truncate">{doctor.email}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    const element = document.getElementById('appointment');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Book Appointment
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredDoctors.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No doctors found matching your criteria.</p>
          </div>
        )}
      </div>
    </section>
  );
}
