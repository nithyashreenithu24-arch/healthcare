import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Jennifer Martinez',
    role: 'Patient',
    rating: 5,
    text: 'The care I received at HealthCare Plus was exceptional. Dr. Johnson was thorough, compassionate, and took the time to answer all my questions. The staff made me feel comfortable throughout my entire visit.',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop'
  },
  {
    id: 2,
    name: 'David Thompson',
    role: 'Patient',
    rating: 5,
    text: 'I highly recommend HealthCare Plus for anyone seeking quality medical care. The facility is clean, modern, and the booking process was incredibly easy. Dr. Chen was excellent with my daughter.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
  },
  {
    id: 3,
    name: 'Sarah Williams',
    role: 'Patient',
    rating: 5,
    text: 'Outstanding service from start to finish! The online appointment system is so convenient, and the medical team is truly professional. I felt heard and well-cared for during my treatment.',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop'
  },
  {
    id: 4,
    name: 'Michael Brown',
    role: 'Patient',
    rating: 5,
    text: 'After my surgery with Dr. Wilson, I can confidently say this is the best healthcare facility in the area. The entire team went above and beyond to ensure my recovery was smooth.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop'
  }
];

export function Testimonials() {
  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
            What Our Patients Say
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Read testimonials from our satisfied patients who have experienced our quality care and compassionate service.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
              <Quote className="w-8 h-8 text-blue-200 mb-3" />

              <div className="flex gap-1 mb-3">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                ))}
              </div>

              <p className="text-gray-700 text-sm mb-4 italic">"{testimonial.text}"</p>

              <div className="flex items-center gap-3 pt-3 border-t border-gray-200">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <div className="font-bold text-blue-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
