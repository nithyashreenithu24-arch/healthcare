import { Apple, Dumbbell, Droplets, Sun, Heart, UtensilsCrossed } from 'lucide-react';

const healthTips = [
  {
    id: 1,
    title: 'Nutrition & Diet',
    icon: Apple,
    color: 'bg-red-100 text-red-600',
    tips: [
      'Eat a balanced diet with plenty of fruits and vegetables',
      'Stay hydrated by drinking 8-10 glasses of water daily',
      'Limit processed foods and added sugars',
      'Include lean proteins and whole grains in your meals'
    ]
  },
  {
    id: 2,
    title: 'Exercise & Fitness',
    icon: Dumbbell,
    color: 'bg-blue-100 text-blue-600',
    tips: [
      'Aim for at least 30 minutes of moderate exercise daily',
      'Include both cardio and strength training exercises',
      'Take short walking breaks if you have a desk job',
      'Stretch regularly to improve flexibility'
    ]
  },
  {
    id: 3,
    title: 'Hygiene & Prevention',
    icon: Droplets,
    color: 'bg-teal-100 text-teal-600',
    tips: [
      'Wash hands frequently with soap and water',
      'Maintain good oral hygiene by brushing twice daily',
      'Get adequate sleep (7-9 hours for adults)',
      'Practice good respiratory hygiene'
    ]
  },
  {
    id: 4,
    title: 'Seasonal Health',
    icon: Sun,
    color: 'bg-yellow-100 text-yellow-600',
    tips: [
      'Stay cool and hydrated during summer months',
      'Boost immunity during flu season with vitamin C',
      'Use sunscreen to protect skin from UV rays',
      'Get seasonal vaccinations as recommended'
    ]
  },
  {
    id: 5,
    title: 'Mental Wellness',
    icon: Heart,
    color: 'bg-pink-100 text-pink-600',
    tips: [
      'Practice stress management techniques like meditation',
      'Maintain social connections with family and friends',
      'Take breaks and practice self-care regularly',
      'Seek professional help if feeling overwhelmed'
    ]
  },
  {
    id: 6,
    title: 'Healthy Eating Habits',
    icon: UtensilsCrossed,
    color: 'bg-green-100 text-green-600',
    tips: [
      'Eat regular meals and avoid skipping breakfast',
      'Practice portion control to maintain healthy weight',
      'Choose healthy snacks like nuts and fruits',
      'Limit caffeine and alcohol consumption'
    ]
  }
];

export function HealthTips() {
  return (
    <section id="health-tips" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
            Daily Health Tips & Wellness Advice
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover practical tips for maintaining a healthy lifestyle. Follow these expert recommendations
            to improve your overall well-being and prevent common health issues.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {healthTips.map((category) => {
            const IconComponent = category.icon;
            return (
              <div key={category.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-12 h-12 rounded-lg ${category.color} flex items-center justify-center`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-blue-900">{category.title}</h3>
                </div>
                <ul className="space-y-2">
                  {category.tips.map((tip, index) => (
                    <li key={index} className="flex items-start gap-2 text-gray-700">
                      <span className="text-green-600 mt-1">•</span>
                      <span className="text-sm">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
