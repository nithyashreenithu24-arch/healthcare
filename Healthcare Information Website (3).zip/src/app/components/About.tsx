import { Target, Award, Users, Heart } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-6">
              About HealthCare Plus
            </h2>
            <p className="text-gray-700 mb-4">
              HealthCare Plus has been serving the community for over 25 years, providing exceptional
              healthcare services with compassion and dedication. Our mission is to deliver patient-centered
              care that improves the health and well-being of every individual we serve.
            </p>
            <p className="text-gray-700 mb-4">
              We combine medical excellence with a personal touch, ensuring that each patient receives
              the highest quality care in a comfortable and welcoming environment. Our team of experienced
              healthcare professionals is committed to staying at the forefront of medical innovation.
            </p>
            <p className="text-gray-700">
              At HealthCare Plus, we believe that everyone deserves access to quality healthcare. We work
              tirelessly to make healthcare accessible, affordable, and effective for all members of our community.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="bg-blue-50 p-6 rounded-lg text-center border-2 border-blue-200">
              <div className="text-4xl font-bold text-blue-600 mb-2">25+</div>
              <div className="text-gray-700">Years of Service</div>
            </div>
            <div className="bg-green-50 p-6 rounded-lg text-center border-2 border-green-200">
              <div className="text-4xl font-bold text-green-600 mb-2">50+</div>
              <div className="text-gray-700">Expert Doctors</div>
            </div>
            <div className="bg-purple-50 p-6 rounded-lg text-center border-2 border-purple-200">
              <div className="text-4xl font-bold text-purple-600 mb-2">100K+</div>
              <div className="text-gray-700">Happy Patients</div>
            </div>
            <div className="bg-orange-50 p-6 rounded-lg text-center border-2 border-orange-200">
              <div className="text-4xl font-bold text-orange-600 mb-2">15+</div>
              <div className="text-gray-700">Departments</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-blue-50 to-white p-6 rounded-lg border border-blue-200">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mb-4">
              <Target className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-blue-900 mb-2">Our Mission</h3>
            <p className="text-sm text-gray-600">
              To provide compassionate, high-quality healthcare services that improve the lives of our patients and community.
            </p>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-white p-6 rounded-lg border border-green-200">
            <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mb-4">
              <Award className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-blue-900 mb-2">Excellence</h3>
            <p className="text-sm text-gray-600">
              We maintain the highest standards of medical care through continuous improvement and innovation.
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-white p-6 rounded-lg border border-purple-200">
            <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-blue-900 mb-2">Community</h3>
            <p className="text-sm text-gray-600">
              We're dedicated to improving the health and wellness of the communities we serve every day.
            </p>
          </div>

          <div className="bg-gradient-to-br from-pink-50 to-white p-6 rounded-lg border border-pink-200">
            <div className="w-12 h-12 bg-pink-600 rounded-lg flex items-center justify-center mb-4">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-blue-900 mb-2">Compassion</h3>
            <p className="text-sm text-gray-600">
              We treat every patient with dignity, respect, and the kindness they deserve during their care.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
